
class student:
    def __init__(self,name,age, subject):
        self.name=name
        self.age=age
        self.subjct=subject
    def __str__(self):
        return f'{self.name} {self.age} {self.subjct}'


shayan = student('shayan', 21, 'Math')
ali    = student('ali', 22, 'science')
print(shayan)
print(ali)
print("*"*40)
class Animal:
    def speak(self, name):
        return(f"{name} makes a sound")
Cat = Animal()
Dog = Animal()
print(Cat.speak('cat'), Dog.speak('dog'), sep ='\n')


