class Car:
    def __init__(self, make, model, year):
        self.make = make
        self.model = model
        self.year = year
    def __str__(self):
        return f'{self.make} {self.model} {self.year}'

Ford = Car('Ford', 'Mustang', 1999)
Bmw  = Car('BMW' , 'i8'     , 2024)

print(Ford,Bmw,sep='\n')