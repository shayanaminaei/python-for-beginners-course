
class Animal:
    def speak(self):
        print('This animal makes a sound')
class Dog(Animal):
    pass

objfarzand = Dog()
objfarzand.speak()
