class User:
    """کلاس پایه برای کاربران"""
    def __init__(self, username, password):
        self.username = username
        self.__password = password  # سطح دسترسی خصوصی

    def login(self, password):
        return self.__password == password


class Admin(User):
    """کلاس مدیر"""
    def __init__(self, username, password):
        super().__init__(username, password)

    def add_product(self, product, inventory):
        inventory.add_product(product)

    def remove_product(self, product_id, inventory):
        inventory.remove_product(product_id)


class Customer(User):
    """کلاس مشتری"""
    def __init__(self, first_name, last_name, username, password, balance):
        super().__init__(username, password)
        self.first_name = first_name
        self.last_name = last_name
        self.cart = []  # سبد خرید
        self.history = []  # تاریخچه خرید
        self.balance = balance  # موجودی حساب

    def add_to_cart(self, product):
        if product.stock > 0:
            self.cart.append(product)
        else:
            print(f"Product {product.name} is out of stock.")

    def view_cart(self):
        return self.cart

    def purchase(self):
        total_price = sum(product.price for product in self.cart)
        if total_price > self.balance:
            print("Insufficient balance to complete the purchase.")
        else:
            for product in self.cart:
                if product.stock > 0:
                    product.stock -= 1
                    self.history.append(product)
                else:
                    print(f"Product {product.name} is out of stock and was not purchased.")
            self.balance -= total_price
            self.cart.clear()
            print("Purchase completed successfully.")

    def view_history(self):
        if not self.history:
            print("No purchase history available.")
        for product in self.history:
            print(f"Purchased: {product.name}, Price: {product.price}")


class Product:
    """کلاس محصولات"""
    def __init__(self, product_id, name, price, description, stock):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.description = description
        self.stock = stock


class Inventory:
    """مدیریت موجودی محصولات"""
    def __init__(self):
        self.products = {}

    def add_product(self, product):
        if product.product_id in self.products:
            print(f"Product with ID {product.product_id} already exists.")
        else:
            self.products[product.product_id] = product
            print(f"Product {product.name} added successfully.")

    def remove_product(self, product_id):
        if product_id in self.products:
            removed = self.products.pop(product_id)
            print(f"Product {removed.name} removed successfully.")
        else:
            print("Product not found.")

    def view_products(self):
        for product in self.products.values():
            print(f"ID: {product.product_id}, Name: {product.name}, Price: {product.price}, Stock: {product.stock}")


# تست برنامه
if __name__ == "__main__":
    inventory = Inventory()

    # ساخت یک ادمین
    admin = Admin("admin", "1234")

    # افزودن محصولات توسط ادمین
    product1 = Product(1, "Laptop", 1500, "A powerful laptop", 10)
    product2 = Product(2, "Phone", 700, "A smartphone", 25)
    product3 = Product(3, "Headphones", 200, "Noise-cancelling headphones", 15)

    admin.add_product(product1, inventory)
    admin.add_product(product2, inventory)
    admin.add_product(product3, inventory)

    # ثبت نام مشتری
    first_name = input("Enter your first name: ")
    last_name = input("Enter your last name: ")
    username = input("Create a username: ")
    password = input("Create a password: ")
    balance = float(input("Enter your initial balance: "))

    customer = Customer(first_name, last_name, username, password, balance)

    while True:
        print("\n1. View Products\n2. Add Product to Cart\n3. View Cart\n4. Purchase\n5. View Purchase History\n6. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            inventory.view_products()
        elif choice == "2":
            product_id = int(input("Enter the product ID to add to cart: "))
            if product_id in inventory.products:
                customer.add_to_cart(inventory.products[product_id])
            else:
                print("Product not found.")
        elif choice == "3":
            print("Cart:", [p.name for p in customer.view_cart()])
        elif choice == "4":
            customer.purchase()
            print("Remaining Balance:", customer.balance)
        elif choice == "5":
            customer.view_history()
        elif choice == "6":
            print("Thank you for visiting our store!")
            break
        else:
            print("Invalid choice. Please try again.")
